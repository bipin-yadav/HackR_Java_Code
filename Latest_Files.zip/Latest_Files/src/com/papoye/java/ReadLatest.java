package com.papoye.java;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Timer;
import java.util.TimerTask;

import org.apache.commons.io.comparator.LastModifiedFileComparator;

import java.io.*;

public class ReadLatest {

	/* Field variables */
	// Yo have to modifiy the path here.
	public static final String FILE_DIR = "D:\\bipin\\poc_papoye\\TestFolder";
	public static final String FILE_TEXT_EXT = ".txt";
	int fileCount = 0;

	/* main method */
	public static void main(String args[]) throws InterruptedException {		
		Timer time = new Timer(); // Instantiate Timer Object
		FindFiles st = new FindFiles(); // Instantiate SheduledTask class
		time.schedule(st, 0, 60000); // Create Repetitively task for every 1 secs
		
	}

	public void listFile(String folder, String ext) {
		GenericExtFilter filter = new GenericExtFilter(ext);
		File dir = new File(folder);
		if (dir.isDirectory() == false) {
			System.out.println("Directory does not exists : " + FILE_DIR);
			return;
		}
		// list out all the file name and filter by the extension
		File[] files = dir.listFiles(filter);
		if (files.length == 0) {
			System.out.println("The directory is empty");
			return;
		} else {
			Arrays.sort(files, LastModifiedFileComparator.LASTMODIFIED_COMPARATOR);
			for (int i = files.length-1; i >= files.length-5; i--) {
				File file = files[i];
				SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss");
				System.out.println("File name: "+ file.getName() + ", last modified :" + sdf.format(file.lastModified())
						+ ", file size :" + file.length());
			}			
		}
	}

	// inner class, generic extension filter
	public class GenericExtFilter implements FilenameFilter {
		private String ext;

		public GenericExtFilter(String ext) {
			this.ext = ext;
		}
		public boolean accept(File dir, String name) {
			return (name.endsWith(ext));
		}
	}

}

class FindFiles extends TimerTask {
	ReadLatest now; 
	public void run() {
		now = new ReadLatest(); 
		now.listFile(ReadLatest.FILE_DIR, ReadLatest.FILE_TEXT_EXT);
	}
}